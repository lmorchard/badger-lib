# Fake settings.py so we can get sphinx autodoc to run against Django without 
# complaining.

DEBUG = True
TEMPLATE_DEBUG = True

DATABASE_ENGINE = ''
DATABASE_NAME = ''
DATABASE_USER = ''

